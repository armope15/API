<?php


class RoutesController{


	/*=============================================
	Ruta Principal
	=============================================*/
	
	public function index(){

		include "routes/routes.php";

	}


}